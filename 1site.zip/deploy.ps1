$commitMessage = "Auto-deploy $(Get-Date -Format 'yyyy-MM-dd HH:mm')"

git add -A
git commit -m "$commitMessage"
git push origin main
